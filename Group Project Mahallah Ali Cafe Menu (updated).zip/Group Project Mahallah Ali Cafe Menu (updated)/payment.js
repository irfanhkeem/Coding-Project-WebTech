// payment.js (for payment.html - Checkout Page)

document.addEventListener('DOMContentLoaded', function() {
    const checkoutCartItemsContainer = document.getElementById('checkout-cart-items');
    const checkoutTotalSpan = document.getElementById('checkout-total');
    const paymentButtons = document.querySelectorAll('.payment-methods button');
    const confirmPaymentButton = document.querySelector('.confirm-payment');

    let currentCart = [];
    let selectedPaymentMethod = 'online-banking'; // Default selected method

    // --- Helper function to save cart to localStorage ---
    function saveCartToLocalStorage() {
        localStorage.setItem('mahallahAliCart', JSON.stringify(currentCart));
    }

    // --- Helper function to load cart from localStorage ---
    function loadCartForCheckout() {
        const storedCart = localStorage.getItem('mahallahAliCart');
        if (storedCart) {
            currentCart = JSON.parse(storedCart);
        } else {
            currentCart = []; // Ensure it's an empty array if nothing found
        }
        displayCheckoutSummary(); // Always call to render cart state
    }

    function displayCheckoutSummary() {
        checkoutCartItemsContainer.innerHTML = ''; // Clear existing display
        let total = 0;

        if (currentCart.length === 0) { // Conditional check
            checkoutCartItemsContainer.innerHTML = '<p>Your cart is empty. Please add items from the menu.</p>';
            confirmPaymentButton.disabled = true; // Disable if cart is empty
        } else {
            currentCart.forEach(item => { // Loop through cart items
                const itemDiv = document.createElement('div'); // Create new element
                itemDiv.classList.add('cart-item'); // Add class
                itemDiv.innerHTML = `
                    <span>${item.name} (RM ${item.price.toFixed(2)})</span>
                    <div class="cart-item-controls">
                        <button class="decrease-quantity" data-id="${item.id}">-</button>
                        <span>${item.quantity}</span>
                        <button class="increase-quantity" data-id="${item.id}">+</button>
                        <button class="remove-item" data-id="${item.id}">Remove</button>
                    </div>
                `;
                checkoutCartItemsContainer.appendChild(itemDiv); // Append to container
                total += item.price * item.quantity;
            });
            confirmPaymentButton.disabled = false; // Enable if cart has items
        }
        checkoutTotalSpan.textContent = `RM ${total.toFixed(2)}`;
    }

    // Event listener for cart item controls (increase/decrease/remove)
    checkoutCartItemsContainer.addEventListener('click', function(e) {
        const target = e.target;
        const itemId = parseInt(target.dataset.id); // Get item ID from data attribute

        if (target.classList.contains('increase-quantity')) {
            const item = currentCart.find(i => i.id === itemId);
            if (item) item.quantity++;
        } else if (target.classList.contains('decrease-quantity')) {
            const item = currentCart.find(i => i.id === itemId);
            if (item && item.quantity > 1) item.quantity--; // Prevent quantity less than 1
        } else if (target.classList.contains('remove-item')) {
    Swal.fire({
        title: 'Are you sure?',
        text: 'This item will be removed from your cart.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, remove it!',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            currentCart = currentCart.filter(item => item.id !== itemId);
            saveCartToLocalStorage();
            displayCheckoutSummary();

            Swal.fire({
                title: 'Removed!',
                text: 'The item has been removed.',
                icon: 'success',
                timer: 1500,
                showConfirmButton: false,
                toast: true,
                position: 'top-end'
            });
        }
    });
    return; // Exit the click handler early to prevent premature updates
}

        saveCartToLocalStorage(); // Save changes to localStorage
        displayCheckoutSummary(); // Re-render the cart display
    });

    // Handle payment method selection
    paymentButtons.forEach(button => {
        button.addEventListener('click', function() {
            paymentButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            selectedPaymentMethod = this.dataset.method;
        });
    });

    // Handle Confirm Payment button
    confirmPaymentButton.addEventListener('click', function() {
        if (currentCart.length === 0) {
            alert('Your cart is empty. Please go back to menu to add items.');
            return;
        }

        // Simulate checkout process
        alert(`Order confirmed! Total: RM ${checkoutTotalSpan.textContent}. Payment method: ${selectedPaymentMethod}.`);

        // Clear the cart from localStorage after successful "checkout"
        localStorage.removeItem('mahallahAliCart');

        // Redirect back to the main menu or a confirmation page
        window.location.href = 'index.html'; //
    });

    // Load cart when the payment page loads
    loadCartForCheckout();
});