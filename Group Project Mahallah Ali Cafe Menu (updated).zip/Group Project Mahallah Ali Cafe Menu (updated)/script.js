// script.js (for index.html - Menu Page)

document.addEventListener('DOMContentLoaded', function() {
    const productsContainer = document.querySelector('.products');
    const cartButton = document.querySelector('.cart-button');
    const searchInput = document.querySelector('.search-cart input[type="text"]');
    const categoryLinks = document.querySelectorAll('.categories a');

    let cart = [];
    let notificationTimeout; // To store the timeout ID for clearing previous notifications

    // --- Helper function to save cart to localStorage ---
    function saveCartToLocalStorage() {
        localStorage.setItem('mahallahAliCart', JSON.stringify(cart));
    }

    // --- Helper function to load cart from localStorage ---
    function loadCartFromLocalStorage() {
        const storedCart = localStorage.getItem('mahallahAliCart');
        if (storedCart) {
            cart = JSON.parse(storedCart);
        } else {
            cart = [];
        }
    }

    // --- Product Data (Hardcoded) ---
    const allProducts = [
        { id: 1, name: "Nasi Goreng Tomyam", price: 7.00, image: "images/nasi goreng tomyam.jpg", category: "rice" },
        { id: 2, name: "Nasi Goreng Kampung", price: 6.50, image: "images/nasi goreng kampung.jpg", category: "rice" },
        { id: 3, name: "Nasi Lemak", price: 5.00, image: "images/nasi lemak.jpg", category: "rice" },
        { id: 4, name: "Char Kuey Teow", price: 7.00, image: "images/char kuey teow.jpg", category: "noodle" },
        { id: 5, name: "Mee Goreng", price: 7.00, image: "images/mee goreng.jpg", category: "noodle" },
        { id: 6, name: "Tomyam Seafood", price: 8.50, image: "images/tomyam seafood.jpg", category: "others" },
        { id: 7, name: "Ayam Goreng Berempah", price: 5.00, image: "images/ayam goreng berempah.jpg", category: "others" },
        { id: 8, name: "Nasi Goreng Telur Mata", price: 4.50, image: "images/nasi goreng telur mata.jpg", category: "rice" },
        { id: 9, name: "Nasi Bujang", price: 3.50, image: "images/nasi bujang.avif", category: "rice" },
        { id: 10, name: "Maggi Goreng", price: 5.00, image: "images/maggi goreng.jpeg", category: "noodle" },
        { id: 11, name: "Nasi Goreng Cina", price: 6.00, image: "images/nasi goreng cina.jpg", category: "rice" },
        { id: 12, name: "Nasi Goreng Patayya", price: 6.00, image: "images/nasi goreng patayya.jpg", category: "rice" },
        { id: 13, name: "Mee Kari", price: 6.00, image: "images/mee kari.jpg", category: "noodle" },
        { id: 14, name: "Nasi Goreng Ayam Kunyit", price: 6.50, image: "images/nasi goreng ayam kunyit.jpg", category: "rice" },
        { id: 15, name: "Sup Ekor", price: 6.00, image: "images/sup ekor.jpg", category: "others" },


    ];

    function renderProducts(productsToDisplay) {
        productsContainer.innerHTML = '';
        productsToDisplay.forEach(product => {
            const productDiv = document.createElement('div');
            productDiv.classList.add('product');
            productDiv.innerHTML = `
                <img src="${product.image}" alt="${product.name}">
                <div class="product-info">
                    <h3>${product.name}</h3>
                    <p>RM ${product.price.toFixed(2)}</p>
                    <button class="add-to-cart" data-id="${product.id}">Add to Cart</button>
                </div>
            `;
            productsContainer.appendChild(productDiv);
        });
    }

    // Initial load from localStorage and render products
    loadCartFromLocalStorage();
    renderProducts(allProducts);
    updateCartButtonCount();

    searchInput.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        const filteredProducts = allProducts.filter(product =>
            product.name.toLowerCase().includes(searchTerm)
        );
        renderProducts(filteredProducts);
    });

    categoryLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();

            categoryLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');

            const category = this.dataset.category;
            let productsToDisplay;
            if (category === 'all') {
                productsToDisplay = allProducts;
            } else {
                productsToDisplay = allProducts.filter(product => product.category === category);
            }
            renderProducts(productsToDisplay);
        });
    });

   productsContainer.addEventListener('click', function(e) {
    if (e.target.classList.contains('add-to-cart')) {
        const productId = parseInt(e.target.dataset.id);
        const productToAdd = allProducts.find(product => product.id === productId);

        if (productToAdd) {
            const existingItem = cart.find(item => item.id === productId);

            if (existingItem) {
                existingItem.quantity++;
            } else {
                cart.push({ ...productToAdd, quantity: 1 });
            }

            saveCartToLocalStorage();
            updateCartButtonCount();

            // Show SweetAlert2 success popup
            Swal.fire({
                title: "Item added to cart!",
                icon: "success",
                confirmButtonText: "OK",
                timer: 1500,
                showConfirmButton: false,
                position: 'top-end',
                toast: true
            });
        }
    }
});


    function updateCartButtonCount() {
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        cartButton.textContent = `Cart (${totalItems})`;
    }

    cartButton.addEventListener('click', function() {
        window.location.href = 'payment.html';
    });


    // --- New Function: showCartNotification ---
    function showCartNotification(message) { // Function declaration
        // Clear any existing notification to prevent multiple pop-ups
        const existingNotification = document.querySelector('.cart-notification');
        if (existingNotification) { // Conditional check
            clearTimeout(notificationTimeout); // Clear previous timeout
            existingNotification.remove(); // Remove old notification
        }

        const notificationDiv = document.createElement('div'); // Create a new div element
        notificationDiv.classList.add('cart-notification'); // Add CSS class
        notificationDiv.textContent = message; // Set the message text

        document.body.appendChild(notificationDiv); // Append to the body

        // Trigger the fade-in animation after a small delay to allow CSS to register the element
        setTimeout(() => {
            notificationDiv.classList.add('show');
        }, 10); // Small delay

        // Set a timeout to hide and remove the notification after 3 seconds
        notificationTimeout = setTimeout(() => { // Using setTimeout
            notificationDiv.classList.remove('show');
            // Remove the element from the DOM after the fade-out transition completes (0.4s + a little buffer)
            setTimeout(() => {
                notificationDiv.remove(); // Remove element
            }, 500); // Wait for transition to finish
        }, 3000); // 3 seconds before starting to hide
    }
});